#!/bin/bash

mkdir backup && mv ~/.bashrc backup && mv .bashrc ~/ && rm install_bashrc_color_terminal_V1.sh && notify-send -i info "My support donate https://money.yandex.ru/to/410014999913799"
cat << EOF >restore_backup_original_bashrc.sh
cd backup && mv .bashrc ~/ && cd - && rm  -Rfv backup && rm restore_backup_original_bashrc.sh && notify-send -i info "My support donate https://money.yandex.ru/to/410014999913799"
EOF
chmod +x restore_backup_original_bashrc.sh
