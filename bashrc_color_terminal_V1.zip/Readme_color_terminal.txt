Griggorii@gmail.com github Example etc skel my global edit OS20 base 19.10

Optional install

sudo apt install libvte-2.91-0 libvte-2.91-common gir1.2-vte-2.91 tilix -y

Click run install_bashrc_color_terminal_V1.sh

Enjoy! Color terminal
