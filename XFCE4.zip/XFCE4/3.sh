#!/bin/bash

cat << EOF >applications.sh
tar cvpjf applications.tar.bz2 ~/.local/share/applications
EOF
chmod +x applications.sh && ./applications.sh && rm applications.sh
cat << EOF >restore_backup_applications.sh
tar xvpfj applications.tar.bz2 -C / && rm applications.tar.bz2 && rm -rf ~/.cache/* && rm restore_backup_applications.sh
EOF
chmod +x restore_backup_applications.sh && rm 3.sh
