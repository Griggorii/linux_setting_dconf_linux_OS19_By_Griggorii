#!/bin/bash

cat << EOF >menus.sh
tar cvpjf menus.tar.bz2 ~/.config/menus
EOF
chmod +x menus.sh && ./menus.sh && rm menus.sh
cat << EOF >restore_backup_menus.sh
tar xvpfj menus.tar.bz2 -C / && rm menus.tar.bz2 && rm -rf ~/.cache/* && rm restore_backup_menus.sh
EOF
chmod +x restore_backup_menus.sh && rm 2.sh
