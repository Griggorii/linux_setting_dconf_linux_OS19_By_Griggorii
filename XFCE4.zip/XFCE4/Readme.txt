Griggorii@gmail.com easy setting xfce4 My OS20 base Ubuntu 19.10 eoan

Universal settings Ubuntu and Mint and MXLinux 16.04/17.04/17.10/18.04/18.10/19.04

                                                                                        Readme


chmod +x Install_xfce4_setting_OS20.sh

run click

_______________________________________________________________________________

Backup restore 

run click restore_setting_backup_original.sh

