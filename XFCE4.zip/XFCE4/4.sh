#!/bin/bash

cat << EOF >desktop-directories.sh
tar cvpjf desktop-directories.tar.bz2 ~/.local/share/desktop-directories
EOF
chmod +x desktop-directories.sh && ./desktop-directories.sh && rm desktop-directories.sh
cat << EOF >restore_backup_desktop-directories.sh
tar xvpfj desktop-directories.tar.bz2 -C / && rm desktop-directories.tar.bz2 && rm -rf ~/.cache/* && rm restore_backup_desktop-directories.sh
EOF
chmod +x restore_backup_desktop-directories.sh && rm 4.sh
