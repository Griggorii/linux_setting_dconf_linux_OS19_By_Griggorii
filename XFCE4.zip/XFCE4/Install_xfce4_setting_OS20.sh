#!/bin/bash
 
mkdir backup && mv 1.sh backup && mv 2.sh backup && mv 3.sh backup && mv 4.sh backup && cd backup && chmod +x ./1.sh && chmod +x ./2.sh && chmod +x ./3.sh && chmod +x ./4.sh && ./1.sh && ./2.sh && ./3.sh && ./4.sh && cd - && tar xvpfj xfce4.tar.bz2 -C ~/.config && tar xvpfj menus.tar.bz2 -C ~/.config && tar xvpfj applications.tar.bz2 -C ~/.local/share && tar xvpfj desktop-directories.tar.bz2 -C ~/.local/share && notify-send -i info "xfce4 alacarte menus setting by Griggorii@gmail.com" && notify-send -i info "My support donate https://money.yandex.ru/to/410014999913799" && rm -rf ~/.cache/*
cat << EOF >restore_setting_backup_original.sh
cd backup && rm  -Rfv ~/.config/xfce4 && rm  -Rfv ~/.config/menus && rm  -Rfv ~/.local/share/applications && rm  -Rfv ~/.local/share/desktop-directories && ./restore_backup_xfce4.sh && ./restore_backup_menus.sh && ./restore_backup_applications.sh && ./restore_backup_desktop-directories.sh && rm -rf ~/.cache/* &&  cd - && rm Install_xfce4_setting_OS20.sh && rm applications.tar.bz2 && rm desktop-directories.tar.bz2 && rm menus.tar.bz2 && rm xfce4.tar.bz2 &&  rm  -Rfv backup && rm restore_setting_backup_original.sh && rm Readme.txt && notify-send -i info "Setting restore apple ! Настройки восстановлены ! https://money.yandex.ru/to/410014999913799" 
EOF
chmod +x restore_setting_backup_original.sh
