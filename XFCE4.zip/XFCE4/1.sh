#!/bin/bash

cat << EOF >xfce4.sh
tar cvpjf xfce4.tar.bz2 ~/.config/xfce4
EOF
chmod +x xfce4.sh && ./xfce4.sh && rm xfce4.sh
cat << EOF >restore_backup_xfce4.sh
tar xvpfj xfce4.tar.bz2 -C / && rm xfce4.tar.bz2 && rm -rf ~/.cache/* && rm restore_backup_xfce4.sh
EOF
chmod +x restore_backup_xfce4.sh && rm 1.sh
